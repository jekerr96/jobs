<head><meta charset="utf-8">
    <title>Даня задолбал</title>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/script.js"></script>

    <link rel="stylesheet" href="jquery-ui.min.css">
    <link rel="stylesheet" href="jquery-ui.structure.min.css">
    <link rel="stylesheet" href="jquery-ui.theme.min.css">

  <style contenteditable="true" media="screen">
  .append_div{
    width: 100px;
    height: 100px;
    position: absolute;
    border: 1px solid black;
  }
  .del{
    position: absolute;
    right: 0;
    top: 0;
    width: 10px;
    height: 10px;
    cursor: pointer;
  }
  </style></head>

  <body style="cursor: auto;">
    <div class="add_div">
      Добавить блок
    </div>
    <div class="save">
      Сохранить
    </div>


<div class="append_div ui-draggable ui-draggable-handle ui-resizable" style="left: 504px; top: 197px; height: 346px; width: 898px; position: absolute;"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div></div><div class="append_div ui-draggable ui-draggable-handle ui-resizable" style="left: 151px; top: 169px; height: 447px; width: 467px; position: absolute;"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div></div>

<div class="append_div ui-draggable ui-draggable-handle ui-resizable" style="position: absolute; left: 462px; top: 25px; height: 453px; width: 557px;"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div></div><div class="append_div ui-draggable ui-draggable-handle ui-resizable" style="position: absolute; left: 217px; top: 48px;"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div></div>
<div contenteditable="true" class="append_div ui-draggable ui-draggable-handle ui-resizable" style="position: absolute; left: 331px; top: 35px; width: 101px; height: 89px;">adasdasadads<img class="del" src="images/del.png"><img class="del" src="images/del.png"><img class="del" src="images/del.png"><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div></div>
</body>